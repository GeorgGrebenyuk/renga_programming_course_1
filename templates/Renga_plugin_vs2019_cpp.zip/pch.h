// add headers that you want to pre-compile here
#include <windows.h>
#include <memory>
#include <list>
#include <string>
//Init all renga header-files
#import "RengaCOMAPI.tlb"
#include <Renga/CreateApplication.hpp>
